package Tools.WordCount;

import DBLP.DBLPPerson;
import java.util.ArrayList;
import java.util.Arrays;

public class Counter {

    ArrayList<Word> wali = new ArrayList<Word>();

    protected void countThis(String s) {

        for (Word w : wali) {
            if (w.word.equalsIgnoreCase(s)) {
                w.increaseCount();
                return;
            }
        }
        wali.add(new Word(s));
    }

    public void count_one(ArrayList<String> ali) {
        wali.clear();
        for (String s : ali) {
//            System.out.println(s);
            s = s.replace('.', ' ').replace(',', ' ').replace('-', ' ').trim().toLowerCase();
//            System.out.println(s);
            String[] words = s.split(" ");
            for (String string : words) {
                countThis(string);
//                System.out.println(string);
            }
        }
//        return wali;
    }

    public void count_two(ArrayList<String> ali) {
        wali.clear();
        for (String s : ali) {
//            System.out.println(s);
            s = s.replace('.', ' ').replace(',', ' ').replace('-', ' ').trim().toLowerCase();
//            System.out.println(s);
            String[] words = s.split(" ");
            for (int i = 0; i < words.length - 1; i++) {
                countThis(words[i] + " " + words[i + 1]);
//                System.out.println(string);
            }
        }
//        return wali;
    }

    public void bisey() {
        DBLPPerson d = new DBLPPerson();
        

        ArrayList<String> pubtitles = new ArrayList<String>();

        for (String w : d.publications("k/Kaya:Mehmet")) {
            String t = d.pubTitle(w);
//            System.out.println(t);
            pubtitles.add(t);
        }

//        ArrayList<Word> wali = ;
//        count_one(pubtitles);
        count_two(pubtitles);
//        Arrays.sort(wali.toArray(), 0, wali.size());

        for (Word w : wali) {
            if (w.count > 0) {
                System.out.println(w.count + " : " + w.word);
            }
        }


    }

    public static void main(String[] args) {

        Counter c = new Counter();
        c.bisey();

    }
}
