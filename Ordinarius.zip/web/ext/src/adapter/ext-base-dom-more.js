/*!
 * Ext JS Library 3.3.1
 * Copyright(c) 2006-2010 Sencha Inc.
 * licensing@sencha.com
 * http://www.sencha.com/license
 */
Ext.lib.Dom.getRegion = function(el) {
    return Ext.lib.Region.getRegion(el);
};