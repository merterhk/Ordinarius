var introPanel=new Ext.Panel({
    title:'Welcome',
    autoScroll:true,
//    frame:true,
    html:'Ordinarius is a academic social network project for suggest new academic person or new conferences etc. <br>\n\
Ordinarius developed width mash-up techniques so it can update itself online.\n\
</ul>\n\
<br>\n\
Project group list below:<br><br>\n\
<b>Project Coordinator:</b><br>\n\
* Merter Hami Karacan<br>\n\
<br><b>Source Research:</b><br>\n\
* Yagmur Kilic<br>\n\
* Rukiye Ubuntu<br>\n\
* Songul Aktepe<br>\n\
* Serpil Gul<br>\n\
<br><b>Developing:</b><br>\n\
* Yunus Emre Hendekci<br>\n\
* Ugur Kocager<br>\n\
* Ridvan Ozbugru<br>\n\
* Onur Salih Gokdere<br>\n\
* Mustafa Agah Ozturk<br>\n\
* Mesut Aydin<br>\n\
* Mehmet Kurt<br>\n\
* Ibrahim Bozan<br>\n\
* Ahmet Aslan<br>\n\
* Abdullah Sener<br>\n\
<br><br><a href="http://www.firat.edu.tr/">Firat University</a> <br> <a href="http://web.firat.edu.tr/bilmuh/">Computer Engineering</a> <br> Software Engineering Student Project <br> Group A (Ordinarius)\n\
\n\
'
});
