package wikiCFP;

public class Category {

    String name, count;

    public Category(String name, String count) {
        this.name = name;
        this.count = count;
    }
}
