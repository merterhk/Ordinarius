
package wikiCFP;

public class CFP {

    String name;
    String link;

    public CFP(String name, String link) {
        this.name = name;
        this.link = link;
    }

    


}
