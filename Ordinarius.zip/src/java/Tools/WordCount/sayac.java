/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools.WordCount;

public class sayac {

    int i = 0;

    public sayac(int i) {
        this.i = i;
    }

    public void art() {
        i++;
    }

    public void azal() {
        i--;
    }
}
