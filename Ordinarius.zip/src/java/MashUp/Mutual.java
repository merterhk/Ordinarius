package MashUp;


public class Mutual {

    String name = "";
    int count = 0;
}
